<?php /* Smarty version 2.6.11, created on 2006-01-24 20:33:53
         compiled from menu.tpl */ ?>
<div id="menu">
    <ul>
<?php $_from = $this->_tpl_vars['topmenu']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['name'] => $this->_tpl_vars['url']):
?>
    	<li><a href="<?php echo $this->_tpl_vars['url']; ?>
"><?php echo $this->_tpl_vars['name']; ?>
</a></li>
<?php endforeach; endif; unset($_from); ?>   
     </ul>
</div>
