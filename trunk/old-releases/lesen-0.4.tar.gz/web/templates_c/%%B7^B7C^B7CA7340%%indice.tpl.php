<?php /* Smarty version 2.6.11, created on 2006-02-27 18:39:27
         compiled from indice.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'upper', 'indice.tpl', 5, false),array('modifier', 'cat', 'indice.tpl', 58, false),)), $this); ?>
<?php if ($this->_tpl_vars['type'] == 'author'): ?>
   <?php $_from = $this->_tpl_vars['author']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['title'] => $this->_tpl_vars['curr_id']):
?>
      <div id="title">
      <h3 id="<?php echo $this->_tpl_vars['title']; ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['title'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)); ?>
</h3>
      </div>
      <ul>
      	<?php $_from = $this->_tpl_vars['curr_id']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['item']):
?>
        <li><a href="index.php?author=<?php echo $this->_tpl_vars['item']['code']; ?>
"><?php echo $this->_tpl_vars['item']['lastname']; ?>
, <?php echo $this->_tpl_vars['item']['name']; ?>
</a></li>
        <?php endforeach; endif; unset($_from); ?>
      </ul>
     <?php endforeach; endif; unset($_from); ?>

<?php elseif ($this->_tpl_vars['type'] == 'paper'): ?>
    <?php $_from = $this->_tpl_vars['paper']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['title'] => $this->_tpl_vars['curr_id']):
?>
    <div id="title">
    <h3 id="<?php echo $this->_tpl_vars['title']; ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['title'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)); ?>
</h3>
    </div>
    <ul>
        <?php $_from = $this->_tpl_vars['curr_id']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['item']):
?>
             <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "paper.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
        <?php endforeach; endif; unset($_from); ?>	
    </ul>
    <?php endforeach; endif; unset($_from); ?>

<?php elseif ($this->_tpl_vars['type'] == 'course'): ?>
    <?php $_from = $this->_tpl_vars['paper']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['title'] => $this->_tpl_vars['curr_id']):
?>
    <div id="title">
    <h3 id="<?php echo $this->_tpl_vars['title']; ?>
"><?php echo $this->_tpl_vars['title']; ?>
</h3>
    </div>
    <ul>
        <?php $_from = $this->_tpl_vars['curr_id']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['item']):
?>
             <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "paper.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
        <?php endforeach; endif; unset($_from); ?>	
    </ul>
    <?php endforeach; endif; unset($_from); ?>

<?php elseif ($this->_tpl_vars['type'] == 'keyword'): ?>
    <?php if ($_GET['lang']): ?>
        <?php $_from = $this->_tpl_vars['keyword']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['title'] => $this->_tpl_vars['curr_id']):
?>
        <div id="title">
        <h3 id="<?php echo $this->_tpl_vars['title']; ?>
"><?php echo $this->_tpl_vars['title']; ?>
</h3>
        </div>
        <ul>
        	<?php $_from = $this->_tpl_vars['curr_id']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['item']):
?>
            	<li><a href="index.php?keyword=<?php echo $this->_tpl_vars['item']['code']; ?>
"><?php echo $this->_tpl_vars['item']['keyword']; ?>
</a></li>
            <?php endforeach; endif; unset($_from); ?>
        </ul>
        <?php endforeach; endif; unset($_from); ?>
    <?php else: ?>
        <div id="title">
        <h3>Selecciona el lenguaje</h3>
        </div>
        <ul>
        	<li><a href="<?php echo ((is_array($_tmp=$_SERVER['REQUEST_URI'])) ? $this->_run_mod_handler('cat', true, $_tmp, "&lang=spanish") : smarty_modifier_cat($_tmp, "&lang=spanish")); ?>
">Espa�ol</a></li>
            <li><a href="<?php echo ((is_array($_tmp=$_SERVER['REQUEST_URI'])) ? $this->_run_mod_handler('cat', true, $_tmp, "&lang=english") : smarty_modifier_cat($_tmp, "&lang=english")); ?>
">Ingl�s</a></li>
        </ul>
        <?php endif;  endif; ?>