<?php /* Smarty version 2.6.11, created on 2006-02-27 18:43:10
         compiled from leftnav.tpl */ ?>
<div id="leftnav">
<?php $_from = $this->_tpl_vars['leftnav']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['title'] => $this->_tpl_vars['item']):
?>
   <h3><?php echo $this->_tpl_vars['title']; ?>
</h3>
    <div>
    <ul>
    <?php $_from = $this->_tpl_vars['item']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['name'] => $this->_tpl_vars['url']):
?>
    	<li><a href="<?php echo $this->_tpl_vars['url']; ?>
"><?php echo $this->_tpl_vars['name']; ?>
</a></li>
    <?php endforeach; endif; unset($_from); ?>   
    </ul>
    </div>

<?php endforeach; endif; unset($_from); ?>



</div>