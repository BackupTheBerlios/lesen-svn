<?php /* Smarty version 2.6.11, created on 2006-01-24 20:33:53
         compiled from header.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'default', 'header.tpl', 8, false),)), $this); ?>
<?php echo '<?xml'; ?>
 version="1.0" encoding="ISO-8859-1"<?php echo '?>'; ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">
<head>
<title><?php echo ((is_array($_tmp=@$this->_tpl_vars['head_title'])) ? $this->_run_mod_handler('default', true, $_tmp, "Ingenier&iacute;a Inform&aacute;tica - UCSP") : smarty_modifier_default($_tmp, "Ingenier&iacute;a Inform&aacute;tica - UCSP")); ?>
</title>
<meta name="author" content="Rodrigo Lazo Paz">
<meta name="date" content="2006-01-20T17:29:25-0500"/>
<meta name="copyright" content=""/>
<meta name="ROBOTS" content="NOINDEX, NOFOLLOW"/>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=ISO-8859-1"/>
<meta http-equiv="Content-Style-Type" content="text/css"/>
<link rel="stylesheet" type="text/css" href="css/style.css"/>
</head>
<body>
<div id="container">