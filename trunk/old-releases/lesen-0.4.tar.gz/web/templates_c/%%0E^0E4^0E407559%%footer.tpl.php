<?php /* Smarty version 2.6.11, created on 2006-01-24 20:33:53
         compiled from footer.tpl */ ?>
 <div id="footer">
  <p>Ingenier&iacute;a Inform&aacute;tica. Copyright &copy; 2006 Rodrigo Lazo</p>
  <p>Todos los derechos reservados</p>
 </div>
</div> </body>
</html>