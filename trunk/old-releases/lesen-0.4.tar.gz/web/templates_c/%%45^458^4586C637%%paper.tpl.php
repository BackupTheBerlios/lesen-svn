<?php /* Smarty version 2.6.11, created on 2006-02-07 11:44:26
         compiled from paper.tpl */ ?>
<li><a href="index.php?paper=<?php echo $this->_tpl_vars['item']['code']; ?>
"><?php echo $this->_tpl_vars['item']['title']; ?>
</a></li>
<p class="index">
	<?php $_from = $this->_tpl_vars['item']['author']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['it'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['it']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['i']):
        $this->_foreach['it']['iteration']++;
?>
       	<?php if ($this->_tpl_vars['i']['webpage']): ?>
	       	<a href="<?php echo $this->_tpl_vars['i']['webpage']; ?>
"><?php echo $this->_tpl_vars['i']['name']; ?>
 <?php echo $this->_tpl_vars['i']['lastname']; ?>
</a> 
        <?php else: ?>
           	<?php echo $this->_tpl_vars['i']['name']; ?>
 <?php echo $this->_tpl_vars['i']['lastname']; ?>
            
       	<?php endif; ?>
        <?php if (($this->_foreach['it']['iteration'] == $this->_foreach['it']['total'])): ?>
            ;
        <?php else: ?>
            ,
        <?php endif; ?>
	<?php endforeach; endif; unset($_from); ?>
	<?php $_from = $this->_tpl_vars['item']['tutor']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['it'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['it']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['i']):
        $this->_foreach['it']['iteration']++;
?>
       	<?php if ($this->_tpl_vars['i']['webpage']): ?>
	    	<a href="<?php echo $this->_tpl_vars['i']['webpage']; ?>
"><?php echo $this->_tpl_vars['i']['name']; ?>
 <?php echo $this->_tpl_vars['i']['lastname']; ?>
</a>
        <?php else: ?>
           	<?php echo $this->_tpl_vars['i']['name']; ?>
 <?php echo $this->_tpl_vars['i']['lastname']; ?>

        <?php if (($this->_foreach['it']['iteration'] == $this->_foreach['it']['total'])): ?>
            .
        <?php else: ?>
            ;
        <?php endif; ?>
	<?php endif; ?>
	<?php endforeach; endif; unset($_from); ?>
</p>