<?php /* Smarty version 2.6.11, created on 2006-02-03 19:01:29
         compiled from paper_full.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'mailto', 'paper_full.tpl', 10, false),)), $this); ?>
<div id="title">
<h3><?php echo $this->_tpl_vars['paper']->getTitle(); ?>
</h3>
</div>
<h4>Autores:</h4>
<ul>
<?php $_from = $this->_tpl_vars['paper']->getAuthors(); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['it']):
 echo '<li>';  echo $this->_tpl_vars['it']['name'];  echo ' ';  echo $this->_tpl_vars['it']['lastname'];  echo ' (';  echo smarty_function_mailto(array('address' => $this->_tpl_vars['it']['mail'],'encode' => 'javascript'), $this); echo ')</li>'; ?>

<?php endforeach; endif; unset($_from); ?>
</ul>
<h4>Asesores:</h4>
<ul>
<?php $_from = $this->_tpl_vars['paper']->getTutors(); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['it']):
 echo '<li>';  echo $this->_tpl_vars['it']['name'];  echo ' ';  echo $this->_tpl_vars['it']['lastname'];  echo ' (';  echo smarty_function_mailto(array('address' => $this->_tpl_vars['it']['mail'],'encode' => 'javascript'), $this); echo ')</li>'; ?>

<?php endforeach; endif; unset($_from); ?>
</ul>

<h4>Palabras clave</h4>
<p class="keyword">
<?php $_from = $this->_tpl_vars['paper']->getKeywords(); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['for'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['for']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['it']):
        $this->_foreach['for']['iteration']++;
?>
	 <?php if (($this->_foreach['for']['iteration'] == $this->_foreach['for']['total'])): ?>
	 <?php echo $this->_tpl_vars['it']['spanish']; ?>
.
	 <?php else: ?>
	 <?php echo $this->_tpl_vars['it']['spanish']; ?>
,
	 <?php endif;  endforeach; endif; unset($_from); ?>
</p>

<!--
<h4>Keywords</h4>
<p class="keyword">
<?php unset($this->_sections['it']);
$this->_sections['it']['name'] = 'it';
$this->_sections['it']['loop'] = is_array($_loop=$this->_tpl_vars['paper']['keywords']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['it']['show'] = true;
$this->_sections['it']['max'] = $this->_sections['it']['loop'];
$this->_sections['it']['step'] = 1;
$this->_sections['it']['start'] = $this->_sections['it']['step'] > 0 ? 0 : $this->_sections['it']['loop']-1;
if ($this->_sections['it']['show']) {
    $this->_sections['it']['total'] = $this->_sections['it']['loop'];
    if ($this->_sections['it']['total'] == 0)
        $this->_sections['it']['show'] = false;
} else
    $this->_sections['it']['total'] = 0;
if ($this->_sections['it']['show']):

            for ($this->_sections['it']['index'] = $this->_sections['it']['start'], $this->_sections['it']['iteration'] = 1;
                 $this->_sections['it']['iteration'] <= $this->_sections['it']['total'];
                 $this->_sections['it']['index'] += $this->_sections['it']['step'], $this->_sections['it']['iteration']++):
$this->_sections['it']['rownum'] = $this->_sections['it']['iteration'];
$this->_sections['it']['index_prev'] = $this->_sections['it']['index'] - $this->_sections['it']['step'];
$this->_sections['it']['index_next'] = $this->_sections['it']['index'] + $this->_sections['it']['step'];
$this->_sections['it']['first']      = ($this->_sections['it']['iteration'] == 1);
$this->_sections['it']['last']       = ($this->_sections['it']['iteration'] == $this->_sections['it']['total']);
?>
	 <?php echo $this->_tpl_vars['paper']['keywords'][$this->_sections['it']['index']]['english']; ?>
, 
<?php endfor; endif; ?>
</p>
-->

<?php $this->assign('des', $this->_tpl_vars['paper']->getAbstracts()); ?>

<?php if ($this->_tpl_vars['des']['english']): ?>
<h4>Abstract</h4>
<p><?php echo $this->_tpl_vars['des']['english']; ?>
 </p>
<?php endif; ?>

<?php if ($this->_tpl_vars['des']['spanish']): ?>
<h4>Resumen</h4>
<p> <?php echo $this->_tpl_vars['des']['spanish']; ?>
 </p>
<?php endif; ?>

<?php if ($this->_tpl_vars['des']['portuguese']): ?>
<h4>Resumo</h4>
<p> <?php echo $this->_tpl_vars['des']['portuguese']; ?>
 </p>
<?php endif; ?>
