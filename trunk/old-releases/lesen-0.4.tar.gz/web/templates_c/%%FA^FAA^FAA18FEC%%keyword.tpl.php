<?php /* Smarty version 2.6.11, created on 2006-01-25 11:47:08
         compiled from keyword.tpl */ ?>
<div id="title">
<h3><?php echo $this->_tpl_vars['paper']['keyword']['spanish']; ?>
 / <?php echo $this->_tpl_vars['paper']['keyword']['english']; ?>
 </h3>
</div>
<ul>
<?php $_from = $this->_tpl_vars['paper']['info']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
 echo '';  $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "paper.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
  echo ''; ?>

<?php endforeach; endif; unset($_from); ?>
</ul>