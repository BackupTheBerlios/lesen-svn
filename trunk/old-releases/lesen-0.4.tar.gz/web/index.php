<?php
require_once('config.php');

require_once(SMARTY_DIR.'Smarty.class.php');
include_once('include/varfunctions.inc.php');
require_once('include/dbfunctions.inc.php');

/* Initialization routine */
$db = initdb($cfg['database']);

$smarty = new Smarty();
$smarty->debugging = true;
$smarty->assign('head_title','Proyectos - Ingenier�a Inform�tica UCSP');
$nav = array('Proyectos' => array('Home' => 'index.php'),
	     '�ndices'   => array('Por autor'         => 'index.php?index=author',
				  'Por t�tulo'        => 'index.php?index=paper',
				  'Por curso'         => 'index.php?index=course',
				  'Por palabra clave' => 'index.php?index=keyword'));

$smarty->assign('leftnav',$nav);
$smarty->assign('topmenu',$topmenu);
/***************************/

/* We want the whole paper */
if (isset($_GET['paper'])) {
  $paper = getPaper($_GET['paper']);
  $paper->generateLatex();
  $smarty->assign('paper',$paper);
  $smarty->display('proyectos.tpl');
 }


/* We just want the list of papers by the author */
 else if (isset($_GET['author'])) {
   $author = getAuthor($_GET['author']);
   $smarty->assign('author',$author);
   $smarty->assign('paper',$author['paper']);
   $smarty->display('proyectos.tpl');
 }
/* We just want the list of paper that share a keyword */
 else if (isset($_GET['keyword'])) {
   $keyword = getKeyword($_GET['keyword']);
   $smarty->assign('paper',$keyword);
   $smarty->display('proyectos.tpl');
 }

/* We need some sort of index */
 else if (isset($_GET['index'])) {
   switch ($_GET['index']) {
     /* author case */
   case 'author':
     $arr = generateIndex(authorIndex(), 'lastname', false, true);
     $nav['Autores'] = navigationIndex($arr);
     $smarty->assign('leftnav', $nav);
     $smarty->assign('type','author');
     $smarty->assign('author', $arr);
     $smarty->display('proyectos.tpl');
     break;
     /* paper case */
   case 'paper':
     $arr = generateIndex(paperIndex(), 'title', false, true);
     $nav['Papers'] = navigationIndex($arr);
     $smarty->assign('leftnav',$nav);
     $smarty->assign('type', 'paper');
     $smarty->assign('paper', $arr);
     $smarty->display('proyectos.tpl');
     break;
     /* course case */
   case 'course':
     $arr = generateIndex(courseIndex(), 'course', 1);
     $nav['Cursos'] = navigationIndex($arr);
     $smarty->assign('leftnav',$nav);
     $smarty->assign('type', 'course');
     $smarty->assign('paper', $arr);
     $smarty->display('proyectos.tpl');
     break;
     /* keyword case */
   case 'keyword':
     $smarty->assign('type', 'keyword');
     if ($_GET['lang'])
       {
	 $arr = generateIndex(keywordIndex($_GET['lang']), 'keyword');
	 $nav['Palabra clave'] = navigationIndex($arr);
	 $smarty->assign('leftnav',$nav);
	 $smarty->assign('keyword', $arr);
       }
     $smarty->display('proyectos.tpl');     
     break;
   default:
     break;
   }
 }
/* We just want the home page */
 else {

function sabsi ($array, $index, $order='asc', $natsort=FALSE, $case_sensitive=FALSE) {
  if(is_array($array) && count($array)>0) {
   foreach(array_keys($array) as $key) $temp[$key]=$array[$key][$index];
   if(!$natsort) ($order=='asc')? asort($temp) : arsort($temp);
   else {
     ($case_sensitive)? natsort($temp) : natcasesort($temp);
     if($order!='asc') $temp=array_reverse($temp,TRUE);
   }
   foreach(array_keys($temp) as $key) (is_numeric($key))? $sorted[]=$array[$key] : $sorted[$key]=$array[$key];
   return $sorted;
  }
  return $array;
}

 $arry = sabsi(array_merge(tutorIndex(),authorIndex()),'lastname');
 // print_r($arry);
 $arr = generateIndex($arry, 'lastname');
 $smarty->assign('g',$arr);
 //print_r($arr);
   $fi = fopen('files/proceedings/author_index.tex','w');
   ob_start();
   foreach ($arr as $key => $val) {
     echo "\\section*{".strtoupper($key)."}\n";
     foreach ($val as $author) {
       echo $author['lastname'].", ".$author['name'].", ";       
       if ($author['code'] >= 20000000){
	 // print "SAS";
	 $tm = getTutor($author['code']);}
       else
	 $tm = getAuthor($author['code']);
       foreach ($tm['paper'] as $g) {
	 $pap[] = "\\pageref{".$g['code']."}";
       }
       echo @join(", ", $pap);
       unset($pap);
       echo "\n\n";
     }
     
   }
   fwrite($fi, ob_get_clean());
   fclose($fi);
   /*   $arr = paperIndex('code');
   $fi = fopen('files/proceedings/author_index.tex','w');
   foreach ($arr as $val) {
     $p = getPaper($val['code']);
     ob_start();
     echo "\\textbf{".$p->getTitle()."}\n\n";
     foreach (array('getAuthors', 'getTutors') as $fun) {
       foreach ($p->$fun() as $val) {
	 $people[] = $val['name']." ".$val['lastname'];
       }
     }
     
     echo "\\textit{".join(", ",$people)."}\\dotfill \pageref{".$p->getCode()."}\n\n";
     echo "\\smallskip\n";
     unset($people);
     fwrite($fi, ob_get_clean());
     }
     fclose($fi);*/
   $smarty->display('proyectos.tpl');
 }

/* Close routine */
mysql_close($db);
/*****************/
?>
