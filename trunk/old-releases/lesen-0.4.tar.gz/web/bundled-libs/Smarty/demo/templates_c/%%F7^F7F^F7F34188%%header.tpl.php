<?php /* Smarty version 2.6.11, created on 2006-01-14 12:18:57
         compiled from header.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'popup_init', 'header.tpl', 3, false),)), $this); ?>
<HTML>
<HEAD>
<?php echo smarty_function_popup_init(array('src' => "/javascripts/overlib.js"), $this);?>

<TITLE><?php echo $this->_tpl_vars['title']; ?>
 - <?php echo $this->_tpl_vars['Name']; ?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">