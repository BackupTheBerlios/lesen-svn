<?php /* Smarty version 2.6.11, created on 2006-01-14 12:18:57
         compiled from footer.tpl */ ?>
</BODY>
</HTML>