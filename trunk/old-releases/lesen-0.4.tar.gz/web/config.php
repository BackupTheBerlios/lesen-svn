<?php
# Database configuration
$cfg['database']['dbhostname']='localhost';
$cfg['database']['dbname']='proyectos';
$cfg['database']['dbusername']='rodrigo';
$cfg['database']['dbpassword']='mailman';

# Path configuration for Smarty
define('SMARTY_DIR', '/home/rodrigo/develop/web/bundled-libs/Smarty/libs/');

# Top menu definition
$topmenu = array('Universidad San Pablo' => "http://www.ucsp.edu.pe",
		 'Proyectos'             => "#",
		 'Mail'                  => "http://inf.ucsp.edu.pe/horde");

# Left Navigation Bar definition
$leftnav = array('General'       => array('Home'                => "index.php",
					  'Perfil del Graduado' => "#",
					  'Plan de estudios'    => "#",
					  'Grados y t�tulos'    => "#",
					  'Infraestructura'     => "#",
					  'Autoridades'         => "#"),
		 'Investigaci�n' => array('Gidis'         => "#",
					  'Proyectos'     => "proyectos.php",
					  'Publicaciones' => "#"),
		 'Personas'      => array('Autoridades' => "#",
					  'Alumnos'     => "#"));

?>